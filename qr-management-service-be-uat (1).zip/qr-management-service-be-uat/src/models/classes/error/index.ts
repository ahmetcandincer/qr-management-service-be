import InternalError from './internalError';
import NotFoundError from './notFoundError';

export { InternalError, NotFoundError };
