export class UserUpdateDTO {
    userNumber: string;
    firstName?: string;
    lastName?: string;
    userName?: string;
    password?: string;
    isActive?: boolean;
}
