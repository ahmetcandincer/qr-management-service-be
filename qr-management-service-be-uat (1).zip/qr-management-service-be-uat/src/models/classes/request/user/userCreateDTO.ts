export class UserCreateDTO {
    firstName: string;
    lastName: string;
    userName: string;
    password: string;
    userNumber?: string;
}
