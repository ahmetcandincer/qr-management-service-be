export class LoginDTO {
    userName: string;
    password: string;
}
