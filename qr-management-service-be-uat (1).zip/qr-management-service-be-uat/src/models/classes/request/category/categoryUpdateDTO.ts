export class CategoryUpdateDTO {
    categoryNumber: string;
    name?: string;
    rank?: string;
    isActive?: string;
}
