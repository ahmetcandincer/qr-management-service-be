export class CategoryCreateDTO {
    categoryNumber?: string;
    name: string;
    rank: string;
}
