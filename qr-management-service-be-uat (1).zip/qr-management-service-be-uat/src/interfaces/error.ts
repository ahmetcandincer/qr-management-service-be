interface InternalError {
    code?: string;
    message: string;
    httpCode?: number;
}

export { InternalError };
