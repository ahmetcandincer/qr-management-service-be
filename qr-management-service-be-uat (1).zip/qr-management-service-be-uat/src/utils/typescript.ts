type ValueOf<T> = T[keyof T];

export { ValueOf };
